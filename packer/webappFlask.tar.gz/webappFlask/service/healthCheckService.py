#!/usr/bin/env python
# -*- coding:utf-8 -*-

from controller.healthCheckController import HealthCheckController


class HealthCheckService(HealthCheckController):
    
    pass
